﻿$ErrorActionPreference = 'Stop'
$installRoot = Join-Path $env:LOCALAPPDATA 'JiayangReport'
$taskName = 'Jiayang-WeChat-PDF'
Write-Host 'Stopping the Jiayang report task...'
$existingTask = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
if ($existingTask) {
    Stop-ScheduledTask -TaskName $taskName -ErrorAction Stop
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction Stop
}
# Stop only the helper's Python and its dedicated browser, not personal WeChat/Chrome.
$rootPrefix = [IO.Path]::GetFullPath($installRoot).TrimEnd('\') + '\'
$profileMarker = Join-Path $installRoot 'browser-profile'
Get-CimInstance Win32_Process | ForEach-Object {
    $ownedPython = $_.ExecutablePath -and $_.ExecutablePath.StartsWith($rootPrefix, [StringComparison]::OrdinalIgnoreCase) -and $_.Name -match '^pythonw?\.exe$'
    $ownedBrowser = $_.Name -match '^(chrome|headless_shell)\.exe$' -and $_.CommandLine -and $_.CommandLine.Contains('--user-data-dir=') -and $_.CommandLine.Contains($profileMarker)
    if ($ownedPython -or $ownedBrowser) { Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop }
}
Start-Sleep -Milliseconds 800
# Remove only Windows Credential Manager entries belonging to this helper.
Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public static class JiayangCredentials {
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
    private struct Credential {
        public uint Flags; public uint Type;
        public IntPtr TargetName; public IntPtr Comment;
        public System.Runtime.InteropServices.ComTypes.FILETIME LastWritten;
        public uint CredentialBlobSize; public IntPtr CredentialBlob;
        public uint Persist; public uint AttributeCount; public IntPtr Attributes;
        public IntPtr TargetAlias; public IntPtr UserName;
    }
    [DllImport("advapi32.dll", EntryPoint="CredEnumerateW", CharSet=CharSet.Unicode, SetLastError=true)]
    private static extern bool Enumerate(string filter, uint flags, out uint count, out IntPtr credentials);
    [DllImport("advapi32.dll", EntryPoint="CredDeleteW", CharSet=CharSet.Unicode, SetLastError=true)]
    private static extern bool Delete(string target, uint type, uint flags);
    [DllImport("advapi32.dll")] private static extern void CredFree(IntPtr pointer);
    public static void Clear() {
        uint count; IntPtr pointer;
        if (!Enumerate(null,0,out count,out pointer)) {
            int code=Marshal.GetLastWin32Error();
            if (code==1168) return;
            throw new System.ComponentModel.Win32Exception(code);
        }
        try {
            const string service="JiayangReport-Workbench";
            for(int i=0;i<count;i++) {
                IntPtr item=Marshal.ReadIntPtr(pointer,i*IntPtr.Size);
                Credential credential=(Credential)Marshal.PtrToStructure(item,typeof(Credential));
                string name=Marshal.PtrToStringUni(credential.TargetName);
                bool owned=name!=null && (name.Equals(service,StringComparison.OrdinalIgnoreCase) || name.StartsWith(service+"/",StringComparison.OrdinalIgnoreCase) || name.EndsWith("@"+service,StringComparison.OrdinalIgnoreCase));
                if(owned && credential.Type==1 && !Delete(name,credential.Type,0))
                    throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
            }
        } finally { CredFree(pointer); }
    }
}
'@
[JiayangCredentials]::Clear()
$shortcut = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Jiayang Report.lnk'
if (Test-Path -LiteralPath $shortcut) { Remove-Item -LiteralPath $shortcut -Force }
# This folder contains only this assistant: settings, reports, logs, browser profile and venv.
if (Test-Path -LiteralPath $installRoot) { Remove-Item -LiteralPath $installRoot -Recurse -Force }
if ((Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) -or (Test-Path -LiteralPath $installRoot) -or (Test-Path -LiteralPath $shortcut)) {
    throw 'Uninstall incomplete. Close the helper and its dedicated browser, then run Uninstall.cmd again.'
}
Write-Host ''
Write-Host 'Jiayang report task, helper files, settings, PDFs, logs, dedicated browser data and saved credentials removed.' -ForegroundColor Green
Write-Host 'Shared Python and Playwright browser installations were left in place to avoid affecting other programs.'
Write-Host 'You can now delete the original setup ZIP, its extracted folder, and this uninstall folder.'
