佳洋报表助手卸载工具

将整个压缩包解压，然后双击 Uninstall.cmd。
请使用安装报表助手时的同一个 Windows 用户运行，无需管理员身份。

本工具会：
- 停止并删除 Jiayang-WeChat-PDF 定时任务。
- 关闭本助手及它的专用浏览器。
- 删除桌面 Jiayang Report 快捷方式。
- 删除本助手在 Windows 凭据管理器中保存的工作台密码。
- 删除 %LOCALAPPDATA%\JiayangReport，包括程序、配置、虚拟环境、
  生成的 PDF、日志、联系人截图，以及专用浏览器里的本地工作台数据。

不会删除普通 Edge/Chrome 中的网站数据，也不会卸载您的微信。
Python 和 Playwright 的共享浏览器缓存不自动删除，以免影响其他程序。
如果它们仅为本工具安装且您不再使用，可在 Windows“设置 → 应用”中卸载 Python；
共享浏览器缓存位于 %LOCALAPPDATA%\ms-playwright，确认没有其他程序使用后再删除。

看到绿色成功提示后，删除之前下载的安装 ZIP、解压出来的安装文件夹，
以及这个卸载工具即可。如提示失败，请保留错误信息，不要认为已经卸载成功。

此脚本由云端生成，尚未在您的 Windows 上执行。
